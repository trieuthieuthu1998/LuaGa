export const version = "random/5.0.9";
//# sourceMappingURL=_version.js.map